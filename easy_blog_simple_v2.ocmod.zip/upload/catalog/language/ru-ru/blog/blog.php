<?php
// Text
$_['button_read_more']           = 'Читать дальше..';
$_['text_empty']           			 = 'Нет статей';
$_['text_error']           			 = 'Нет статей';