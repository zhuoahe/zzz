<?php
// Text
$_['button_read_more']         		 = 'Devamı ...';
$_['text_empty']           			 = 'Makale bulunamadı';
$_['text_error']           			 = 'Makale bulunamadı';
